package unidade_5;

public class exerc2_ContaEspecial extends exerc2_Conta {
    
    @Override
    public void imprimirTipoConta(){
        System.out.println("Conta Especial");     
    }
    
}
