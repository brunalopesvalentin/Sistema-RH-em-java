package unidade_5;

public class exerc2_Conta {

    public void imprimirTipoConta(){
        System.out.println("Conta Comum");
    }
    
}
