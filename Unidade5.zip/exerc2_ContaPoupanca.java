package unidade_5;

public class exerc2_ContaPoupanca extends exerc2_Conta {
    
    @Override
    public void imprimirTipoConta(){
        System.out.println("Conta Poupan�a");     
    }
    
}