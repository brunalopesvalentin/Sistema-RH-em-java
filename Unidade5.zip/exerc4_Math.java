package unidade_5;

public class exerc4_Math {

    public int arredondar(double valor) 
    {
        return (int) Math.round(valor);
    }
    
}
