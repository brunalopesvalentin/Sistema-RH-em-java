package unidade_5;

import javax.swing.JOptionPane;

public class exerc2_Teste {
        
        public static void main(String[] args) {
            
        exerc2_Conta c = null;
        
        String menu = "Selecione o tipo de conta para abrir:\n"
                + "1 - Conta Comum\n"
                + "2 - Conta Poupança\n"
                + "3 - Conta Especial";    
        byte opcao = Byte.parseByte(
                JOptionPane.showInputDialog(menu));
        switch (opcao) {
            case 1: c = new exerc2_Conta(); break;
            case 2: c = new exerc2_ContaEspecial(); break;
            case 3: c = new exerc2_ContaPoupanca(); break;
            default: JOptionPane
                    .showMessageDialog(null, "Tipo de conta inválida");
        }
        if (c !=null){
            c.imprimirTipoConta();
        
    }
        }
    
    
    /*public static void main(String[] args) {
        Conta c = new Conta();
        c.imprimirTipoConta();
        ContaEspecial ce = new ContaEspecial();
        ce.imprimirTipoConta();
        ContaPoupanca cp = new ContaPoupanca();
        cp.imprimirTipoConta();
    }*/
    
}
