package unidade_5;

public class exerc1_Soma {

        public int doisValores(int a,int b) { // soma dois inteiros
           return a+b;
 }
        public double doisValores(double a,int b) { // soma um double e um inteiro
            return a+b;
}
        public double doisValores(double a,double b) { // soma dois doubles
            return a+b;
}
} 

