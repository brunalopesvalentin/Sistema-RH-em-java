package unidade_5;

public class exerc3_teste {

    public static void main(String[] args) {
        
        int resultadoSoma = exerc3_metodoEstatico.somar(5, 10, 15);
        System.out.println("A soma dos três valores é: " + resultadoSoma);

        int resultadoSubtracao = exerc3_metodoEstatico.subtracao(20, 5, 3);
        System.out.println("A subtração dos três valores é: " + resultadoSubtracao);
    }
}
