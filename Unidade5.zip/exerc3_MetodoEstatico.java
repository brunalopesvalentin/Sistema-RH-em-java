package unidade_5;

public class exerc3_metodoEstatico {

    public static int somar(int a, int b, int c) {
        return a + b + c;
    }

    public static int subtracao(int a, int b, int c) {
        return a - b - c;
    }
}
